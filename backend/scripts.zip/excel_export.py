# -*- coding: utf-8 -*-
"""Genera la descarga Excel a partir de la plantilla entregada."""
from copy import copy
from datetime import datetime
from io import BytesIO
import re
import unicodedata

from openpyxl import load_workbook

from dictionary import VARIABLES


def _nombre_territorio(nivel, codigo):
    for clave, nombre in VARIABLES.get("geografia", {}).get(nivel, {}).items():
        if str(clave).isdigit() and str(codigo).isdigit() and int(clave) == int(codigo):
            return nombre
    return str(codigo or "")


def _campos_geograficos(respuesta, propiedades):
    nivel = respuesta.get("nivel_geografico") or "territorio"
    interp = respuesta.get("interpretacion") or {}
    filtro = interp.get("filtro_geografico_nivel")
    codigo_filtro = interp.get("filtro_geografico_codigo")
    nombre = propiedades.get("nombre", "")
    if nivel == "comuna" and filtro in ("region", "provincia"):
        return [filtro.capitalize(), _nombre_territorio(filtro, codigo_filtro),
                "Comuna", nombre]
    return [nivel.capitalize(), nombre, None, None]


def _copiar_estilo_fila(ws, origen, destino):
    for columna in range(1, 9):
        fuente, celda = ws.cell(origen, columna), ws.cell(destino, columna)
        celda._style = copy(fuente._style)
        celda.font = copy(fuente.font)
        celda.fill = copy(fuente.fill)
        celda.border = copy(fuente.border)
        celda.alignment = copy(fuente.alignment)
        celda.number_format = fuente.number_format


def _filas_resultado(respuesta):
    filas = []
    tortas = respuesta.get("tipo_visualizacion") == "tortas_mapa"
    # Admite tanto respuestas nuevas (datos separados) como resultados
    # aprobados con el formato GeoJSON anterior.
    registros = respuesta.get("datos")
    if registros is None:
        registros = [feature.get("properties") or {}
                     for feature in (respuesta.get("geojson") or {}).get("features", [])]
    for p in registros:
        geo = _campos_geograficos(respuesta, p)
        if tortas:
            total = p.get("total")
            for item in p.get("distribucion") or []:
                filas.append(geo + [item.get("etiqueta"), item.get("valor"),
                                    item.get("porcentaje"), total])
        else:
            filas.append(geo + [None, None, None, p.get("valor")])
    return filas, tortas


def nombre_archivo(titulo):
    texto = unicodedata.normalize("NFKD", titulo or "resultados_censo")
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = re.sub(r"[^A-Za-z0-9]+", "_", texto).strip("_").lower()
    return (texto[:45].rstrip("_") or "resultados_censo") + ".xlsx"


def crear_excel(plantilla, respuesta, pregunta, sql):
    if not plantilla.exists():
        raise FileNotFoundError(f"No se encontró la plantilla Excel en '{plantilla}'.")
    wb = load_workbook(plantilla)
    if not {"Nota", "Resultado"}.issubset(wb.sheetnames):
        raise ValueError("La plantilla debe contener las hojas Nota y Resultado.")
    nota, resultado = wb["Nota"], wb["Resultado"]
    interp = respuesta.get("interpretacion") or {}
    titulo = interp.get("descripcion") or "Resultados de la consulta"
    resultado["A1"] = titulo
    nota["B5"] = "Fecha de obtención del cuadro: " + datetime.now().strftime("%d-%m-%Y %H:%M")
    metadatos = [
        ("Pregunta", pregunta),
        ("Tabla", interp.get("tabla")),
        ("Variable", interp.get("variable")),
        ("Operación", interp.get("operacion")),
        ("Nivel geográfico", interp.get("nivel_geografico")),
        ("Instrucción SQL", sql),
    ]
    for fila, (nombre, valor) in enumerate(metadatos, start=14):
        nota.cell(fila, 2, nombre)
        nota.cell(fila, 5, "" if valor is None else str(valor))

    filas, tortas = _filas_resultado(respuesta)
    if not filas:
        raise ValueError("No hay resultados para exportar.")
    encabezados = [
        "Nivel geográfico primario", "Nombre del territorio primario",
        "Nivel geográfico secundario (opcional)", "Nombre del territorio secundario",
        "Categoría", "Cantidad", "Porcentaje", "Total o valor del indicador/tasa/porcentaje",
    ]
    for columna, encabezado in enumerate(encabezados, start=1):
        resultado.cell(3, columna, encabezado)
    if not tortas:
        resultado["E3"], resultado["F3"], resultado["G3"] = "Categoría", "Cantidad", "Porcentaje"

    cantidad = len(filas)
    extra = max(0, cantidad - 16)
    try:
        resultado.unmerge_cells("A22:I22")
    except ValueError:
        pass
    if extra:
        resultado.insert_rows(20, amount=extra)
    for indice, valores in enumerate(filas, start=4):
        estilo = 4 if indice == 4 else (19 if indice == 3 + cantidad else 5)
        _copiar_estilo_fila(resultado, estilo, indice)
        for columna, valor in enumerate(valores, start=1):
            resultado.cell(indice, columna, valor)
    # Limpia filas de muestra sobrantes sin eliminar el formato de la plantilla.
    for fila in range(4 + cantidad, 20 + extra):
        for columna in range(1, 9):
            resultado.cell(fila, columna, None)
    pie = 22 + extra
    resultado.merge_cells(start_row=pie, start_column=1, end_row=pie, end_column=9)
    resultado.row_dimensions[pie].height = 48
    resultado.freeze_panes = "A4"
    resultado.auto_filter.ref = f"A3:H{3 + cantidad}"
    salida = BytesIO()
    wb.save(salida)
    salida.seek(0)
    return salida, nombre_archivo(titulo)
