# -*- coding: utf-8 -*-
"""
Interpreta una consulta en español en lenguaje natural y la transforma en
una "intención" estructurada que el motor de datos (data_engine.py) puede
ejecutar directamente contra los parquet + la cartografía.

Usa un LLM liviano corriendo LOCALMENTE vía Ollama (http://localhost:11434).
No se hace ninguna llamada a internet ni a APIs externas: si Ollama no está
corriendo, se usa un modo de respaldo (heurístico, sin LLM) para que la
aplicación nunca quede totalmente bloqueada.

Modelos locales recomendados (livianos, con buen español):
    ollama pull qwen2.5:3b-instruct     # recomendado, ~2 GB, rápido en CPU
    ollama pull llama3.2:3b             # alternativa liviana
    ollama pull gemma2:2b               # aún más liviano si tu equipo es limitado
"""
import json
import re
import requests
import logging
import os
from time import perf_counter, monotonic
from collections import OrderedDict
from copy import deepcopy
from threading import RLock

from dictionary import (
    VARIABLES,
    _norm,
    filtro_geografico_explicito,
    nombres_geograficos,
    buscar_variables,
    buscar_geografia,
    detectar_nivel_geografico,
    detectar_operacion,
    TABLAS_PARQUET,
    categorias_validas,
    es_ambito_nacional,
)
from semantic_catalog import resolver_indicador
from range_resolver import resolver_rango_numerico
from categorical_resolver import (
    resolver_referencia_censo,
    resolver_operacion_omitida,
    resolver_distribucion,
    resolver_porcentaje_generico,
    resolver_conteo_categoria,
)

OLLAMA_URL = "http://localhost:11434/api/generate"
MODELO_LLM = "qwen2.5:3b-instruct"  # cambia esto si usas otro modelo local
TIMEOUT_SEG = float(os.getenv("OLLAMA_TIMEOUT", "30"))
LOG = logging.getLogger("uvicorn.error")
_INTERPRETACION_LOCK = RLock()
_CACHE_INTERPRETACIONES = OrderedDict()
# Tras un timeout evita repetir inmediatamente una espera de 30 segundos.
OLLAMA_REINTENTO_SEG = max(1.0, float(os.getenv("OLLAMA_REINTENTO_SEG", "60")))
_OLLAMA_REINTENTAR_DESDE = 0.0


def _construir_prompt(consulta: str, candidatos_var, candidatos_geo, nivel_defecto, operacion_defecto):
    lineas_var = []
    for i, c in enumerate(candidatos_var):
        cats = ""
        if c["categorias"]:
            pares = ", ".join(f'{k}="{v}"' for k, v in list(c["categorias"].items())[:15])
            cats = f" | valores posibles: {pares}"
        lineas_var.append(f'{i}. tabla="{c["tabla"]}" variable="{c["variable"]}" ({c["descripcion"]}){cats}')

    lineas_geo = []
    for g in candidatos_geo:
        lineas_geo.append(f'- {g["nivel"]}: "{g["nombre"]}" (codigo={g["codigo"]})')

    # Prompt compacto: conserva candidatos y el contrato de salida existente.
    prompt = f"""Traduce la pregunta del Censo de Chile a JSON. Solo JSON.
Variables (elige una de la lista):
{chr(10).join(lineas_var)}
Territorios candidatos:
{chr(10).join(lineas_geo) or "ninguno"}
Claves: tabla, variable, categoria_valor, operacion,
filtro_geografico_nivel, filtro_geografico_codigo.
Operacion: conteo, porcentaje o promedio (predeterminado: {operacion_defecto}).
Categoria: codigo solo si se pide una categoria; en promedios, null.
Filtro: nivel region/provincia/comuna y codigo del lugar solicitado;
si no hay un lugar concreto, ambos null. Usa null real, no texto "null".
"Por region" indica agregacion, no un filtro. Si Chile es el ambito nacional
y no hay otro nivel explicito, usa region y no trates Chile como categoria.
"Casa" y "casas" son la categoria Casa de Tipo de vivienda particular.
"Nacidas fuera de Chile" es una categoria de lugar de nacimiento, no
nacionalidad ni filtro territorial, si dice "Censo 2024" elimínalo, si dice totales usa total, si dice población usa persona.
El nivel del mapa y la edad minima se resuelven por separado.
Ambiguedades: si dice internet sin especificar si es internet fija, internet móvil desde un celular, tablet o BAM o satelital, 
pregúntale al usuario a cuál se refiere p15d_serv_internet_fija o p15e_serv_internet_movil o p15e_serv_internet_movil o p15e_serv_internet_movil
o 15e_serv_internet_movil o p15f_serv_internet_satelital y luego procesa la categoría seleccionada con categoría==1.
Pregunta: {consulta}
"""
    print(prompt)
    return prompt


def _llamar_ollama(prompt: str) -> str:
    inicio = perf_counter()
    resp = requests.post(
        OLLAMA_URL,
        json={
            "model": MODELO_LLM,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "keep_alive": "30m",
            "options": {"temperature": 0.0, "num_predict": 256},
        },
        timeout=TIMEOUT_SEG,
    )
    resp.raise_for_status()
    data = resp.json()
    LOG.info("[tiempo] ollama=%.3fs carga=%.3fs prompt=%.3fs generacion=%.3fs",
             perf_counter() - inicio, data.get("load_duration", 0) / 1e9,
             data.get("prompt_eval_duration", 0) / 1e9,
             data.get("eval_duration", 0) / 1e9)
    return data.get("response", "")


def _extraer_json(texto: str):
    texto = texto.strip()
    texto = re.sub(r"^```(json)?", "", texto).strip()
    texto = re.sub(r"```$", "", texto).strip()
    match = re.search(r"\{.*\}", texto, re.DOTALL)
    if not match:
        raise ValueError("El modelo no devolvió JSON reconocible")
    return json.loads(match.group(0))


def _respaldo_heuristico(consulta: str, candidatos_var, candidatos_geo, nivel_defecto, operacion_defecto):
    """Si el LLM local no está disponible o falla, se usa la mejor
    coincidencia por texto en vez de dejar la app sin respuesta."""
    if not candidatos_var:
        return None
    mejor = candidatos_var[0]
    categoria_valor = None
    q = consulta.lower()
    for codigo, etiqueta in mejor["categorias"].items():
        if etiqueta.lower() in q:
            categoria_valor = codigo
            break
    geo = candidatos_geo[0] if candidatos_geo else None
    return {
        "tabla": mejor["tabla"],
        "variable": mejor["variable"],
        "categoria_valor": categoria_valor,
        "operacion": operacion_defecto,
        "nivel_geografico": nivel_defecto,
        "filtro_geografico_nivel": geo["nivel"] if geo else None,
        "filtro_geografico_codigo": geo["codigo"] if geo else None,
    }


def _resolver_promedio_explicito(consulta, nivel, operacion):
    """Ruta rápida conservadora: variable única y sin términos sin interpretar."""
    if operacion != "promedio":
        return None
    q = _norm(consulta)
    geo = filtro_geografico_explicito(consulta)
    menciones = buscar_geografia(consulta, top_n=100)
    if menciones and geo is None:
        # «Antofagasta» sin nivel puede designar más de un territorio.
        return None
    candidatos = []
    for tabla in TABLAS_PARQUET:
        for variable, info in VARIABLES[tabla]["variables"].items():
            descripcion = _norm(info["descripcion"]).strip()
            # No se deduce que una variable categórica sea continua.
            if info["categorias"]:
                continue
            frase = descripcion if len(descripcion.split()) >= 2 else ""
            if frase and re.search(r"\b" + re.escape(frase) + r"\b", q):
                candidatos.append((tabla, variable, frase))
            elif "escolaridad" in descripcion and re.search(r"\bescolaridad\b", q):
                candidatos.append((tabla, variable, "escolaridad"))
    if len(candidatos) != 1:
        return None
    tabla, variable, frase = candidatos[0]
    resto = re.sub(r"\b" + re.escape(frase) + r"\b", " ", q)
    resto = re.sub(r"\b\d{1,3}\s+anos?\s+o\s+mas\b", " ", resto)
    if geo:
        # Solo retira el nombre del filtro seleccionado, no otros lugares.
        nombre = re.sub(r"^(?:region|provincia|comuna)\s+(?:de\s+)?", "", geo["nombre_norm"])
        resto = re.sub(r"\b" + re.escape(nombre) + r"\b", " ", resto)
    permitidas = set("mapea mapa mapear muestra mostrar muestrame dame ver quiero "
                     "el la los las de del en por un una a para y promedio media "
                     "anos ano poblacion personas cada nivel comuna comunas comunal "
                     "provincia provincias provincial region regiones regional".split())
    if set(re.findall(r"[a-z0-9]+", resto)) - permitidas:
        # Por ejemplo «mujeres», «rural» o una negación requieren el LLM.
        return None
    return {"tabla": tabla, "variable": variable, "categoria_valor": None,
            "operacion": operacion, "filtro_geografico_nivel": geo["nivel"] if geo else None,
            "filtro_geografico_codigo": geo["codigo"] if geo else None}


def _normalizar_filtro_territorial(consulta, intencion):
    """Ancla el filtro a lugares del texto, nunca solo al nivel que da el LLM."""
    geo = filtro_geografico_explicito(consulta)
    if geo:
        intencion["filtro_geografico_nivel"] = geo["nivel"]
        intencion["filtro_geografico_codigo"] = geo["codigo"]
        return
    # Usa límites de palabra para descartar coincidencias parciales de nombres.
    q = _norm(consulta)
    candidatos = [g for g in buscar_geografia(consulta, top_n=100)
                  if any(re.search(r"\b" + re.escape(nombre) + r"\b", q)
                         for nombre in nombres_geograficos(g))]
    if not candidatos:
        # Si hay una solicitud territorial explícita pero desconocida, no
        # convertirla silenciosamente en una consulta nacional.
        if re.search(r"\b(?:en|para|dentro de)\s+(?:la\s+)?"
                     r"(?:region|provincia|comuna)\s+de\s+\w+", q):
            raise ValueError("No se reconoció el territorio solicitado en el diccionario geográfico.")
        # «Por región» por sí solo no restringe ninguna unidad geográfica.
        if intencion.get("filtro_geografico_nivel") is not None or intencion.get("filtro_geografico_codigo") is not None:
            LOG.info("[interpretacion] filtro del LLM descartado: no hay un lugar concreto en la pregunta")
        intencion["filtro_geografico_nivel"] = None
        intencion["filtro_geografico_codigo"] = None
        return
    # Una mención única permite completar ambos campos aun con un JSON parcial.
    unicos = {(g["nivel"], str(g["codigo"])): g for g in candidatos}
    if len(unicos) == 1:
        geo = next(iter(unicos.values()))
    else:
        # En homónimos solo acepta una elección completa compatible con el texto.
        nivel = intencion.get("filtro_geografico_nivel")
        codigo = str(intencion.get("filtro_geografico_codigo"))
        compatibles = [g for g in unicos.values() if g["nivel"] == nivel
                       and codigo.isdigit() and str(g["codigo"]).isdigit()
                       and int(codigo) == int(g["codigo"])]
        if len(compatibles) != 1:
            raise ValueError("El lugar mencionado es ambiguo; indicar región, provincia o comuna y su nombre.")
        geo = compatibles[0]
    intencion["filtro_geografico_nivel"] = geo["nivel"]
    intencion["filtro_geografico_codigo"] = geo["codigo"]


def _asegurar_categoria_nacimiento(consulta, intencion):
    """Impide contar toda la población al omitirse la categoría de nacimiento."""
    q = _norm(consulta)
    if not re.search(r"\bnacid[oa]s?\s+(?:fuera de chile|en (?:el )?extranjero|en otro pais)\b", q):
        return
    opciones = []
    # Los códigos salen del diccionario del usuario, no se presupone un valor.
    for variable, info in VARIABLES["personas"]["variables"].items():
        descripcion = _norm(info["descripcion"])
        if not re.search(r"\b(?:nacimiento|nacer|nacio|nacid[oa]s?)\b", descripcion):
            continue
        for codigo, etiqueta in info["categorias"].items():
            etiqueta = _norm(etiqueta).strip().rstrip(".")
            if re.fullmatch(r"(?:en (?:el )?)?extranjero|(?:en )?otro pais|"
                            r"(?:nacid[oa]s? )?fuera de chile|(?:en )?un pais distinto (?:a|de) chile", etiqueta):
                opciones.append((variable, codigo))
    elegidas = [o for o in opciones if intencion.get("tabla") == "personas"
                and o[0] == intencion.get("variable")]
    if len(elegidas) == 1:
        variable, codigo = elegidas[0]
    elif len(opciones) == 1:
        variable, codigo = opciones[0]
    else:
        raise ValueError("No se identificó de forma inequívoca la categoría de personas nacidas fuera de Chile. "
                         "Revisar la variable de lugar de nacimiento y sus categorías en diccionario_variables.json.")
    intencion["tabla"] = "personas"
    intencion["variable"] = variable
    intencion["categoria_valor"] = codigo
    intencion["operacion"] = detectar_operacion(consulta)
    if intencion["operacion"] == "porcentaje":
        intencion["denominador_valores"] = categorias_validas("personas", variable)


def _resolver_nacimiento_explicito(consulta, operacion):
    """Conteo/porcentaje de nacidos fuera de Chile con condiciones reconocidas."""
    q = _norm(consulta)
    patron = r"\bnacid[oa]s?\s+(?:fuera de chile|en (?:el )?extranjero|en otro pais)\b"
    if operacion not in ("conteo", "porcentaje") or not re.search(patron, q):
        return None
    resto = re.sub(patron, " ", q)
    resto = re.sub(r"\b\d{1,3}\s+anos?\s+o\s+mas\b", " ", resto)
    geo = filtro_geografico_explicito(consulta)
    if geo:
        for nombre in nombres_geograficos(geo):
            resto = re.sub(r"\b" + re.escape(nombre) + r"\b", " ", resto)
    elif buscar_geografia(consulta, top_n=100):
        return None
    permitidas = set("cantidad numero total conteo porcentaje proporcion personas poblacion "
                     "de del la el los las por cada a nivel en para y mapea mapa "
                     "muestra muestrame dame ver quiero region regiones regional "
                     "comuna comunas comunal provincia provincias provincial".split())
    if set(re.findall(r"[a-z0-9]+", resto)) - permitidas:
        return None
    intencion = {"operacion": operacion}
    _asegurar_categoria_nacimiento(consulta, intencion)
    _normalizar_filtro_territorial(consulta, intencion)
    return intencion


def _resolver_sexo_explicito(consulta, operacion):
    """Resuelve conteos por sexo solo si todas las restricciones son reconocidas."""
    q = _norm(consulta)
    grupos = [(r"\bmujeres\b|\bmujer\b", {"mujer", "mujeres", "femenino", "femenina"}, "mujeres"),
              (r"\bhombres\b|\bhombre\b", {"hombre", "hombres", "masculino", "masculina"}, "hombres")]
    coincidencias = [(patron, etiquetas, nombre) for patron, etiquetas, nombre in grupos
                     if re.search(patron, q)]
    if operacion not in ("conteo", "porcentaje") or len(coincidencias) != 1:
        return None
    patron, etiquetas, nombre = coincidencias[0]
    resto = re.sub(patron, " ", q)
    resto = re.sub(r"\b\d{1,3}\s+anos?\s+o\s+mas\b", " ", resto)
    geo = filtro_geografico_explicito(consulta)
    if geo:
        for lugar in nombres_geograficos(geo):
            resto = re.sub(r"\b" + re.escape(lugar) + r"\b", " ", resto)
    elif buscar_geografia(consulta, top_n=100):
        return None
    permitidas = set("cantidad numero total conteo porcentaje proporcion personas poblacion "
                     "de del la el los las por cada a nivel en para dame mapea mapa "
                     "muestra muestrame ver quiero region regiones regional "
                     "comuna comunas comunal provincia provincias provincial".split())
    if set(re.findall(r"[a-z0-9]+", resto)) - permitidas:
        # No reemplaza preguntas sobre hijas, madres, nacimientos u otros filtros.
        return None
    opciones = []
    for variable, info in VARIABLES["personas"]["variables"].items():
        descripcion = _norm(info["descripcion"])
        # Solo sexo de la persona, nunca sexo/cantidad de familiares.
        if not re.search(r"\bsexo\b", descripcion):
            continue
        if re.search(r"\b(?:hij[oa]s?|madre|padre|pareja|conyuge|jef[ea]|nacimient[oa]s?)\b", descripcion):
            continue
        for codigo, etiqueta in info["categorias"].items():
            if _norm(etiqueta).strip().rstrip(".") in etiquetas:
                opciones.append((variable, codigo))
    if len(opciones) != 1:
        raise ValueError("No se identificó de forma única la variable de sexo y su categoría. "
                         "Se necesita revisar data/diccionario_variables.json para evitar un conteo incorrecto.")
    variable, codigo = opciones[0]
    intencion = {"tabla": "personas", "variable": variable, "categoria_valor": codigo,
                 "operacion": operacion, "_grupo_personas": nombre}
    if operacion == "porcentaje":
        intencion["denominador_valores"] = categorias_validas("personas", variable)
    _normalizar_filtro_territorial(consulta, intencion)
    return intencion


def _interpretar_consulta(consulta: str, tabla_seleccionada=None,
                          variable_seleccionada=None,
                          operacion_seleccionada=None) -> dict:
    """Punto de entrada principal: consulta en texto -> intención estructurada."""
    inicio = perf_counter()
    candidatos_var = buscar_variables(consulta, top_n=6)
    if tabla_seleccionada and variable_seleccionada:
        info_forzada = VARIABLES.get(tabla_seleccionada, {}).get(
            "variables", {}).get(variable_seleccionada)
        if info_forzada:
            candidatos_var = [{
                "tabla": tabla_seleccionada, "variable": variable_seleccionada,
                "descripcion": info_forzada["descripcion"],
                "categorias": info_forzada["categorias"],
            }]
    candidatos_geo = buscar_geografia(consulta, top_n=5)
    nivel_defecto = detectar_nivel_geografico(consulta)
    operacion_defecto = detectar_operacion(consulta)

    LOG.info("[tiempo] candidatos=%.3fs", perf_counter() - inicio)
    global _OLLAMA_REINTENTAR_DESDE
    # Un año censal puede significar residencia anterior, período de llegada
    # u otra variable. La persona decide antes de invocar al LLM.
    resolver_referencia_censo(
        consulta, tabla_forzada=tabla_seleccionada,
        variable_forzada=variable_seleccionada,
    )
    # Los cálculos registrados se resuelven con el diccionario antes del LLM.
    intencion = resolver_operacion_omitida(
        consulta, tabla_forzada=tabla_seleccionada,
        variable_forzada=variable_seleccionada,
        operacion_forzada=operacion_seleccionada,
    )
    if intencion is None:
        intencion = resolver_distribucion(
            consulta, tabla_forzada=tabla_seleccionada,
            variable_forzada=variable_seleccionada,
        )
    if intencion is None:
        intencion = resolver_indicador(consulta)
    if intencion is None:
        intencion = resolver_porcentaje_generico(
            consulta, tabla_forzada=tabla_seleccionada,
            variable_forzada=variable_seleccionada,
        )
    if intencion is None:
        intencion = _resolver_sexo_explicito(consulta, operacion_defecto)
    if intencion is None:
        intencion = _resolver_nacimiento_explicito(consulta, operacion_defecto)
    if intencion is None:
        intencion = resolver_rango_numerico(consulta)
    if intencion is None:
        intencion = resolver_conteo_categoria(
            consulta, tabla_forzada=tabla_seleccionada,
            variable_forzada=variable_seleccionada,
        )
    if intencion is None:
        intencion = _resolver_promedio_explicito(consulta, nivel_defecto, operacion_defecto)
    origen = (intencion.get("_origen_interpretacion", "reglas_verificadas")
              if intencion else "llm_local")
    if intencion is None and operacion_defecto == "razon":
        raise ValueError(
            "El índice solicitado no tiene una fórmula registrada. "
            "Agrégalo al catálogo semántico indicando numerador, denominador y factor."
        )
    if intencion is None:
        try:
            if monotonic() < _OLLAMA_REINTENTAR_DESDE:
                raise requests.RequestException("Ollama en pausa temporal después de un fallo")
            prompt = _construir_prompt(consulta, candidatos_var, candidatos_geo, nivel_defecto, operacion_defecto)
            texto_llm = _llamar_ollama(prompt)
            intencion = _extraer_json(texto_llm)
            if not isinstance(intencion, dict):
                raise ValueError("La respuesta no es un objeto JSON")
            _OLLAMA_REINTENTAR_DESDE = 0.0
        except (requests.RequestException, ValueError, TypeError) as exc:
            # La pausa no se prolonga con cada consulta recibida.
            if monotonic() >= _OLLAMA_REINTENTAR_DESDE:
                _OLLAMA_REINTENTAR_DESDE = monotonic() + OLLAMA_REINTENTO_SEG
            LOG.warning("[tiempo] interpretacion_llm_fallida=%.3fs: %s", perf_counter() - inicio, exc)
            origen = f"respaldo_heuristico (LLM no disponible: {exc})"
            intencion = _respaldo_heuristico(consulta, candidatos_var, candidatos_geo, nivel_defecto, operacion_defecto)

    # Repara nacimiento con el diccionario ANTES de rechazar nombres del LLM.
    # En la versión anterior el error de esquema impedía llegar a esta regla.
    if isinstance(intencion, dict):
        _asegurar_categoria_nacimiento(consulta, intencion)
        if tabla_seleccionada and variable_seleccionada:
            info_forzada = VARIABLES.get(tabla_seleccionada, {}).get(
                "variables", {}).get(variable_seleccionada)
            if info_forzada is None:
                raise ValueError("La variable seleccionada no existe en el diccionario.")
            intencion["tabla"] = tabla_seleccionada
            intencion["variable"] = variable_seleccionada
            categoria = intencion.get("categoria_valor")
            if categoria is not None and str(categoria) not in {
                    str(c) for c in info_forzada["categorias"]}:
                intencion["categoria_valor"] = None

    if not intencion or not intencion.get("tabla") or not intencion.get("variable"):
        print(f"""intencion={intencion}, intencion.get("tabla")={intencion.get("tabla")},  intencion.get("variable")={intencion.get("tabla")}""")
        raise ValueError(
            "No se pudo identificar una variable del censo relacionada con la pregunta. "
            "Intenta reformularla usando términos como: sexo, edad, migración, "
            "pueblos indígenas, hacinamiento, internet, vivienda, escolaridad, etc."
        )

    # No permite que una respuesta del modelo inserte identificadores SQL.
    tabla = intencion["tabla"]
    variable = intencion["variable"]
    if tabla not in TABLAS_PARQUET or variable not in VARIABLES[tabla]["variables"]:
        LOG.warning("[interpretacion] identificadores no válidos: tabla=%r variable=%r; candidatos=%s",
                    tabla, variable, [(c["tabla"], c["variable"]) for c in candidatos_var])
        raise ValueError("El modelo seleccionó una tabla o variable que no existe en el diccionario.")
    # El nivel se fija con reglas verificables, aunque el LLM sugiera otro.
    # «Chile» sin nivel explícito produce un mapa regional y no un filtro.
    intencion["nivel_geografico"] = (
        "region" if es_ambito_nacional(consulta)
        and detectar_nivel_geografico(consulta) == "region"
        else nivel_defecto
    )
    # Normaliza los null textuales antes de reparar el filtro del modelo.
    for campo in ("categoria_valor", "filtro_geografico_nivel", "filtro_geografico_codigo"):
        valor = intencion.get(campo)
        if isinstance(valor, str) and valor.strip().lower() in ("null", "none", ""):
            intencion[campo] = None
    _normalizar_filtro_territorial(consulta, intencion)
    tabla = intencion["tabla"]
    variable = intencion["variable"]
    if intencion.get("operacion") not in (
            "conteo", "porcentaje", "porcentaje_rango", "promedio", "razon", "distribucion"):
        intencion["operacion"] = operacion_defecto
    categorias = VARIABLES[tabla]["variables"][variable]["categorias"]
    categoria = intencion.get("categoria_valor")
    if categoria is not None and str(categoria) not in {str(c) for c in categorias}:
        raise ValueError("La categoría seleccionada no existe en el diccionario.")
    if intencion["operacion"] == "porcentaje":
        if categoria is None:
            raise ValueError("Para calcular un porcentaje se necesita una categoría objetivo.")
        intencion.setdefault("denominador_valores", categorias_validas(tabla, variable))
        intencion["denominador_valores"] = list(dict.fromkeys(
            str(v) for v in intencion["denominador_valores"]
        ))
        if len(intencion["denominador_valores"]) < 2:
            raise ValueError(
                "No se puede calcular el porcentaje: la variable no tiene al menos "
                "dos categorías válidas en el diccionario."
            )
        if str(categoria) not in intencion["denominador_valores"]:
            raise ValueError(
                "No se puede calcular el porcentaje: la categoría objetivo no "
                "pertenece al universo válido de la variable."
            )
    if intencion["operacion"] == "porcentaje_rango":
        rango = intencion.get("rango_objetivo")
        if not isinstance(rango, dict) or rango.get("variable") != variable:
            raise ValueError("El porcentaje por rango no tiene una variable objetivo válida.")
    if intencion["operacion"] == "razon":
        if not intencion.get("numerador_valores") or not intencion.get("denominador_valores"):
            raise ValueError("El índice no tiene numerador y denominador válidos.")
    if intencion["operacion"] == "distribucion":
        validas = intencion.get("categorias_validas") or categorias_validas(tabla, variable)
        if len(validas) < 2:
            raise ValueError("La distribución requiere al menos dos categorías válidas.")
        intencion["categorias_validas"] = validas
    # La restricción de edad se extrae del texto, no se deja a criterio del LLM.
    edad = (None if intencion.get("rango_objetivo") or intencion.get("filtros_numericos")
            else re.search(r"\b(\d{1,3})\s+anos?\s+o\s+mas\b", _norm(consulta)))
    if edad:
        if tabla != "personas":
            raise ValueError("El filtro de edad requiere una variable de la tabla personas.")
        posibles = [v for v, info in VARIABLES[tabla]["variables"].items()
                    if _norm(v) == "edad" or _norm(info["descripcion"]).strip() in
                    ("edad", "edad en anos", "edad en anos cumplidos")]
        if len(posibles) != 1:
            raise ValueError("No se identificó de forma única la variable de edad; revisar el diccionario.")
        intencion["edad_minima"] = int(edad.group(1))
        intencion["variable_edad"] = posibles[0]

    # Rechaza códigos territoriales inventados por el modelo.
    f_nivel = intencion.get("filtro_geografico_nivel")
    f_codigo = intencion.get("filtro_geografico_codigo")
    if bool(f_nivel) != (f_codigo is not None):
        raise ValueError("El filtro territorial está incompleto.")
    if f_nivel:
        codigos = VARIABLES["geografia"].get(f_nivel, {})
        if not str(f_codigo).isdigit() or not any(
                str(c).isdigit() and int(c) == int(f_codigo) for c in codigos):
            raise ValueError("El filtro territorial no existe en el diccionario.")
    intencion.setdefault("operacion", operacion_defecto)
    intencion.setdefault("filtro_geografico_nivel", None)
    intencion.setdefault("filtro_geografico_codigo", None)
    intencion["_origen_interpretacion"] = origen
    LOG.info("[interpretacion] tabla=%s variable=%s categoria=%s operacion=%s "
             "nivel_mapa=%s filtro_nivel=%s filtro_codigo=%s",
             tabla, variable, intencion.get("categoria_valor"), intencion["operacion"],
             nivel_defecto, intencion.get("filtro_geografico_nivel"),
             intencion.get("filtro_geografico_codigo"))
    return intencion


def interpretar_consulta(consulta: str, tabla_seleccionada=None,
                         variable_seleccionada=None,
                         operacion_seleccionada=None) -> dict:
    """LRU acotada: respuestas de respaldo expiran sin borrar las exitosas."""
    inicio = perf_counter()
    # Mayúsculas, tildes y espacios extra no fuerzan otra llamada al modelo.
    clave = (re.sub(r"\s+", " ", _norm(consulta)).strip(),
             tabla_seleccionada, variable_seleccionada, operacion_seleccionada)
    with _INTERPRETACION_LOCK:
        entrada = _CACHE_INTERPRETACIONES.get(clave)
        hit = entrada is not None and monotonic() < entrada[0]
        if hit:
            resultado = deepcopy(entrada[1])
            _CACHE_INTERPRETACIONES.move_to_end(clave)
        else:
            resultado = _interpretar_consulta(
                consulta.strip(), tabla_seleccionada, variable_seleccionada,
                operacion_seleccionada,
            )
            vencimiento = (_OLLAMA_REINTENTAR_DESDE
                           if resultado["_origen_interpretacion"].startswith("respaldo")
                           else float("inf"))
            _CACHE_INTERPRETACIONES[clave] = (vencimiento, deepcopy(resultado))
            _CACHE_INTERPRETACIONES.move_to_end(clave)
            while len(_CACHE_INTERPRETACIONES) > 128:
                _CACHE_INTERPRETACIONES.popitem(last=False)
    LOG.info("[tiempo] interpretacion_total=%.3fs cache=%s origen=%s pid=%s",
             perf_counter() - inicio, hit, resultado["_origen_interpretacion"], os.getpid())
    return resultado
