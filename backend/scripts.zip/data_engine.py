# -*- coding: utf-8 -*-
"""
Ejecuta la intención estructurada (ver nl_parser.py) contra:
  - los archivos parquet del Censo 2024 (datos/*.parquet), usando DuckDB
  - la cartografía CPV24 (cartografia/Cartografia_censo2024_Pais.gdb),
    usando GeoPandas/Fiona

y devuelve un GeoJSON listo para pintar en el mapa (Leaflet).
"""
import difflib
import hashlib
import json
import math
import os
from copy import deepcopy
from uuid import uuid4
import logging
from time import perf_counter
from functools import lru_cache
from threading import RLock
import pandas as pd
from pathlib import Path

import duckdb
import geopandas as gpd

from dictionary import VARIABLES, TABLAS_PARQUET, categorias_validas

BASE_DIR = Path(__file__).resolve().parent.parent
DATOS_DIR = BASE_DIR / "datos"
GDB_PATH = BASE_DIR / "cartografia" / "Cartografia_censo2024_Pais.gdb"

# Nivel geográfico -> (columna en el parquet, capa "ideal" del gdb, campo llave en el gdb)
NIVELES = {
    "region": {"col_parquet": "region", "capa_gdb": "Regional_CPV24", "campo_gdb": "COD_REGION", "campo_nombre": "REGION"},
    "provincia": {"col_parquet": "provincia", "capa_gdb": "Provincial_CPV24", "campo_gdb": "COD_PROVINCIA", "campo_nombre": "PROVINCIA"},
    "comuna": {"col_parquet": "comuna", "capa_gdb": "Comunal_CPV24", "campo_gdb": "CUT", "campo_nombre": "COMUNA"},
}

_capas_cache = None
_GEOMETRIAS = {}
# La caché persistente contiene solo cartografía preparada, nunca microdatos.
CACHE_DIR = Path(os.getenv("CENSO_CACHE_DIR", str(BASE_DIR / ".cache_visor")))
SIMPLIFICACION = float(os.getenv("CENSO_SIMPLIFICACION", "0.0005"))
if not 0 < SIMPLIFICACION < 1:
    raise ValueError("CENSO_SIMPLIFICACION debe ser mayor que cero y menor que 1 grado.")
_FIRMAS_GEOMETRIA = {}
_GEOMETRIAS_JSON = {}
_GEOMETRY_LOCK = RLock()
_SQL_CACHE_LOCK = RLock()
_PREWARM_LOCK = RLock()
LOG = logging.getLogger("uvicorn.error")
_ESTADO_PRECALENTAMIENTO = {
    "estado": "pendiente", "niveles_listos": [], "errores": {},
}


def _numero_sql(valor, nombre):
    """Valida un límite numérico antes de incorporarlo al SQL."""
    try:
        numero = float(valor)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{nombre} no es numérico.") from exc
    if not math.isfinite(numero):
        raise ValueError(f"{nombre} no es finito.")
    return str(int(numero)) if numero.is_integer() else repr(numero)


def _condiciones_rango(tabla, filtro, incluir_solicitado=True):
    """Construye condiciones validadas para el dominio y el rango solicitado."""
    variable = filtro.get("variable")
    if variable not in VARIABLES.get(tabla, {}).get("variables", {}):
        raise ValueError("La variable del filtro numérico no existe en el diccionario.")
    variable_sql = '"' + variable.replace('"', '""') + '"'
    expresion = f"TRY_CAST({variable_sql} AS DOUBLE)"
    condiciones = [f"{expresion} IS NOT NULL"]
    if filtro.get("dominio_minimo") is not None:
        condiciones.append(f"{expresion} >= {_numero_sql(filtro['dominio_minimo'], 'dominio_minimo')}")
    if filtro.get("dominio_maximo") is not None:
        condiciones.append(f"{expresion} <= {_numero_sql(filtro['dominio_maximo'], 'dominio_maximo')}")
    if incluir_solicitado and filtro.get("minimo") is not None:
        operador = ">=" if filtro.get("incluir_minimo", True) else ">"
        condiciones.append(f"{expresion} {operador} {_numero_sql(filtro['minimo'], 'mínimo')}")
    if incluir_solicitado and filtro.get("maximo") is not None:
        operador = "<=" if filtro.get("incluir_maximo", True) else "<"
        condiciones.append(f"{expresion} {operador} {_numero_sql(filtro['maximo'], 'máximo')}")
    minimo, maximo = filtro.get("minimo"), filtro.get("maximo")
    if minimo is not None and maximo is not None and float(minimo) > float(maximo):
        raise ValueError("El límite mínimo del rango es mayor que el máximo.")
    return condiciones


def _listar_capas():
    global _capas_cache
    if _capas_cache is None:
        _capas_cache = gpd.list_layers(GDB_PATH)["name"].tolist() if GDB_PATH.exists() else []
    return _capas_cache


def _resolver_capa(nombre_ideal: str) -> str:
    """Encuentra el nombre real de la capa dentro del .gdb, por si difiere
    levemente del nombre del diccionario (mayúsculas, sufijos, etc.)."""
    capas = _listar_capas()
    if not capas:
        raise FileNotFoundError(
            f"No se encontró la geodatabase en '{GDB_PATH}'. Verifica la carpeta 'cartografia/'."
        )
    if nombre_ideal in capas:
        return nombre_ideal
    coincidencia = difflib.get_close_matches(nombre_ideal, capas, n=1, cutoff=0.4)
    if coincidencia:
        return coincidencia[0]
    raise ValueError(f"No se encontró una capa similar a '{nombre_ideal}'. Capas disponibles: {capas}")


def _ruta_parquet(tabla: str) -> Path:
    ruta = DATOS_DIR / TABLAS_PARQUET[tabla]
    if not ruta.exists():
        raise FileNotFoundError(f"No se encontró '{ruta}'. Verifica la carpeta 'datos/'.")
    return ruta


def _construir_sql(intencion: dict, nivel_info: dict, ruta_parquet: Path) -> str:
    tabla = intencion["tabla"]
    variable = intencion["variable"]
    valor = intencion.get("categoria_valor")
    operacion = intencion.get("operacion", "conteo")
    col_geo = nivel_info["col_parquet"]

    # Valida y cita los identificadores; las categorías se escapan como literales.
    if tabla not in TABLAS_PARQUET or variable not in VARIABLES[tabla]["variables"]:
        raise ValueError("Tabla o variable desconocida.")
    variable = '"' + variable.replace('"', '""') + '"'
    if valor is not None:
        valor = str(valor).replace("'", "''")
    if operacion not in ("conteo", "porcentaje", "porcentaje_rango", "promedio", "razon"):
        raise ValueError("Operación no admitida.")
    filtros = []
    if intencion.get("edad_minima") is not None:
        edad = intencion.get("variable_edad")
        if tabla != "personas" or edad not in VARIABLES[tabla]["variables"]:
            raise ValueError("Variable de edad no válida.")
        edad = '"' + edad.replace('"', '""') + '"'
        filtros.append(f"TRY_CAST({edad} AS DOUBLE) >= {int(intencion['edad_minima'])}")
    f_nivel = intencion.get("filtro_geografico_nivel")
    f_codigo = intencion.get("filtro_geografico_codigo")
    if bool(f_nivel) != (f_codigo is not None) or (f_nivel and f_nivel not in NIVELES):
        raise ValueError("Filtro territorial incompleto o no válido.")
    if f_nivel and f_codigo is not None and f_nivel in NIVELES:
        col_filtro = NIVELES[f_nivel]["col_parquet"]
        filtros.append(f"{col_filtro} = {int(f_codigo)}")

    # Los filtros numéricos adicionales restringen el universo completo. El
    # rango objetivo de un porcentaje se procesa aparte para no producir 100 %.
    for filtro_numerico in intencion.get("filtros_numericos") or []:
        filtros.extend(_condiciones_rango(tabla, filtro_numerico, incluir_solicitado=True))

    ruta_sql = ruta_parquet.as_posix().replace("'", "''")
    origen = f"read_parquet('{ruta_sql}')"

    if operacion == "promedio":
        # se descartan códigos negativos típicos de "no aplica"/"no responde"
        filtros.append(f"TRY_CAST({variable} AS DOUBLE) IS NOT NULL")
        filtros.append(f"TRY_CAST({variable} AS DOUBLE) >= 0")
        where = ("WHERE " + " AND ".join(filtros)) if filtros else ""
        sql = f"""
            SELECT {col_geo} AS codigo, AVG(TRY_CAST({variable} AS DOUBLE)) AS valor
            FROM {origen}
            {where}
            GROUP BY {col_geo}
        """
        return sql

    if operacion == "porcentaje_rango":
        rango = intencion.get("rango_objetivo")
        if not isinstance(rango, dict):
            raise ValueError("El porcentaje por rango requiere límites numéricos.")
        condicion_num = " AND ".join(_condiciones_rango(tabla, rango, incluir_solicitado=True))
        condicion_den = " AND ".join(_condiciones_rango(tabla, rango, incluir_solicitado=False))
        where_total = ("WHERE " + " AND ".join(filtros)) if filtros else ""
        LOG.info("[rango] tabla=%s variable=%s minimo=%s maximo=%s",
                 tabla, rango.get("variable"), rango.get("minimo"), rango.get("maximo"))
        return f"""
            SELECT {col_geo} AS codigo,
                   100.0 * SUM(CASE WHEN {condicion_num} THEN 1 ELSE 0 END)
                   / NULLIF(SUM(CASE WHEN {condicion_den} THEN 1 ELSE 0 END), 0) AS valor
            FROM {origen}
            {where_total}
            GROUP BY {col_geo}
        """

    if operacion == "porcentaje":
        where_total = ("WHERE " + " AND ".join(filtros)) if filtros else ""
        if valor is None:
            raise ValueError("Un porcentaje requiere una categoría objetivo.")
        denominador = intencion.get("denominador_valores") or categorias_validas(
            tabla, intencion["variable"]
        )
        denominador = list(dict.fromkeys(str(v) for v in denominador))
        if len(denominador) < 2:
            raise ValueError(
                "El porcentaje requiere al menos dos categorías válidas en el denominador."
            )
        if str(intencion.get("categoria_valor")) not in denominador:
            raise ValueError(
                "La categoría objetivo no pertenece al denominador válido de la variable."
            )
        LOG.info("[porcentaje] tabla=%s variable=%s objetivo=%s denominador=%s",
                 tabla, intencion["variable"], intencion.get("categoria_valor"), denominador)
        valores_den = ", ".join("'" + str(v).replace("'", "''") + "'" for v in denominador)
        # Excluye No aplica, No respuesta y códigos especiales del universo.
        condicion = f"CAST({variable} AS VARCHAR) = '{valor}'"
        condicion_den = f"CAST({variable} AS VARCHAR) IN ({valores_den})"
        return f"""
            SELECT {col_geo} AS codigo,
                   100.0 * SUM(CASE WHEN {condicion} THEN 1 ELSE 0 END)
                   / NULLIF(SUM(CASE WHEN {condicion_den} THEN 1 ELSE 0 END), 0) AS valor
            FROM {origen} {where_total}
            GROUP BY {col_geo}
        """

    if operacion == "razon":
        numerador = intencion.get("numerador_valores") or []
        denominador = intencion.get("denominador_valores") or []
        if not numerador or not denominador:
            raise ValueError("Una razón requiere categorías de numerador y denominador.")
        lista_num = ", ".join("'" + str(v).replace("'", "''") + "'" for v in numerador)
        lista_den = ", ".join("'" + str(v).replace("'", "''") + "'" for v in denominador)
        factor = float(intencion.get("factor", 1.0))
        where = ("WHERE " + " AND ".join(filtros)) if filtros else ""
        return f"""
            SELECT {col_geo} AS codigo,
                   {factor} * SUM(CASE WHEN CAST({variable} AS VARCHAR) IN ({lista_num}) THEN 1 ELSE 0 END)
                   / NULLIF(SUM(CASE WHEN CAST({variable} AS VARCHAR) IN ({lista_den}) THEN 1 ELSE 0 END), 0) AS valor
            FROM {origen}
            {where}
            GROUP BY {col_geo}
        """

    # Cuenta la categoría dentro de cada grupo para conservar ceros reales
    # cuando existen personas en la comuna, pero ninguna cumple la categoría.
    agregado = (f"SUM(CASE WHEN CAST({variable} AS VARCHAR) = '{valor}' THEN 1 ELSE 0 END)"
                if valor is not None else "COUNT(*)")
    where = ("WHERE " + " AND ".join(filtros)) if filtros else ""

    print(f"""
        SELECT {col_geo} AS codigo, {agregado} AS valor
        FROM {origen}
        {where}
        GROUP BY {col_geo}
    """)
    return f"""
        SELECT {col_geo} AS codigo, {agregado} AS valor
        FROM {origen}
        {where}
        GROUP BY {col_geo}
    """


def _firma_geometria(nivel):
    """Invalida por ruta, tamaño/fecha de los archivos, configuración y versión."""
    archivos = []
    if GDB_PATH.exists():
        entradas = GDB_PATH.rglob("*") if GDB_PATH.is_dir() else [GDB_PATH]
        for ruta in entradas:
            # Los locks de GDAL pueden cambiar al leer y no modifican los datos.
            if ruta.is_file() and not ruta.name.lower().endswith(".lock"):
                st = ruta.stat()
                archivos.append((str(ruta.relative_to(GDB_PATH.parent)), st.st_size, st.st_mtime_ns))
    config = ["capas-v2", str(GDB_PATH.resolve()), sorted(archivos),
              nivel, NIVELES[nivel], SIMPLIFICACION, gpd.__version__]
    return hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:24]


def _guardar_capa(gdf, ruta):
    """Escritura atómica; si el disco no permite guardar, conserva la caché RAM."""
    temporal = ruta.with_name(f"{ruta.stem}-{uuid4().hex}.tmp.gpkg")
    try:
        ruta.parent.mkdir(parents=True, exist_ok=True)
        gdf.to_file(temporal, layer="capa", driver="GPKG", index=False)
        os.replace(temporal, ruta)
    except Exception as exc:
        LOG.warning("No se pudo guardar la caché de cartografía: %s", exc)
    finally:
        if temporal.exists():
            try:
                temporal.unlink()
            except OSError:
                pass


def _cargar_geometria(nivel):
    """RAM -> cartografía preparada en disco -> geodatabase original."""
    inicio = perf_counter()
    with _GEOMETRY_LOCK:
        firma = _firma_geometria(nivel)
        info = NIVELES[nivel]
        origen = "memoria"
        hit = nivel in _GEOMETRIAS and _FIRMAS_GEOMETRIA.get(nivel) == firma
        if not hit:
            ruta_cache = CACHE_DIR / f"{nivel}-{firma}.gpkg"
            gdf = None
            if ruta_cache.exists():
                try:
                    paso = perf_counter()
                    gdf = gpd.read_file(ruta_cache, layer="capa")
                    if gdf.crs is None or gdf.crs.to_epsg() != 4326:
                        raise ValueError("CRS de caché incorrecto")
                    for campo in (info["campo_gdb"], info["campo_nombre"]):
                        if campo not in gdf:
                            raise ValueError(f"La caché no contiene {campo}")
                    origen = "disco"
                    LOG.info("[tiempo] lectura_cache_disco[%s]=%.3fs", nivel, perf_counter() - paso)
                except Exception as exc:
                    LOG.warning("Caché de cartografía ilegible; se regenerará: %s", exc)
                    gdf = None
            if gdf is None:
                origen = "gdb"
                # Refresca la lista por si la geodatabase cambió en este proceso.
                global _capas_cache
                _capas_cache = None
                capa = _resolver_capa(info["capa_gdb"])
                paso = perf_counter()
                gdf = gpd.read_file(GDB_PATH, layer=capa)
                LOG.info("[tiempo] lectura_gdb[%s]=%.3fs", nivel, perf_counter() - paso)
                for campo in (info["campo_gdb"], info["campo_nombre"]):
                    if campo not in gdf:
                        raise ValueError(f"La capa {capa} no contiene {campo}.")
                paso = perf_counter()
                if gdf.crs is None:
                    raise ValueError(f"La capa {capa} no tiene sistema de coordenadas definido.")
                # Guarda solo campos necesarios para nombres, llaves y filtros.
                campos = {"geometry", info["campo_gdb"], info["campo_nombre"]}
                campos.update(v["campo_gdb"] for v in NIVELES.values())
                gdf = gdf[[c for c in gdf.columns if c in campos]].to_crs(4326)
                gdf["geometry"] = gdf.geometry.simplify(SIMPLIFICACION, preserve_topology=True)
                LOG.info("[tiempo] reproyeccion_simplificacion[%s]=%.3fs", nivel, perf_counter() - paso)
                paso = perf_counter()
                _guardar_capa(gdf, ruta_cache)
                LOG.info("[tiempo] guardar_cache_disco[%s]=%.3fs", nivel, perf_counter() - paso)
            gdf[info["campo_gdb"]] = pd.to_numeric(gdf[info["campo_gdb"]], errors="raise").astype("Int64")
            _GEOMETRIAS[nivel] = gdf
            _FIRMAS_GEOMETRIA[nivel] = firma
        # Cada solicitud trabaja sobre una copia para no alterar la caché.
        resultado = _GEOMETRIAS[nivel].copy()
    LOG.info("[tiempo] geometria[%s]=%.3fs cache=%s origen=%s pid=%s",
             nivel, perf_counter() - inicio, origen != "gdb", origen, os.getpid())
    return resultado


def _codigo_json(valor):
    """Convierte códigos pandas/numpy a enteros JSON cuando corresponde."""
    if pd.isna(valor):
        return None
    try:
        return int(valor)
    except (TypeError, ValueError):
        return str(valor)


def _valor_json(valor):
    """Evita NaN y tipos numpy en las respuestas del API."""
    if pd.isna(valor):
        return None
    if hasattr(valor, "item"):
        valor = valor.item()
    return valor


def referencia_geometria(nivel, filtro_nivel=None, filtro_codigo=None):
    """Describe una capa reutilizable sin incluir sus polígonos en la consulta."""
    if nivel not in NIVELES:
        raise ValueError("Nivel geográfico no válido.")
    if bool(filtro_nivel) != (filtro_codigo is not None):
        raise ValueError("Filtro territorial incompleto.")
    if filtro_nivel and filtro_nivel not in NIVELES:
        raise ValueError("Nivel del filtro territorial no válido.")
    # La precarga registra la firma. Si aún no terminó, calcularla no obliga a
    # leer la capa y permite que la consulta entregue la referencia enseguida.
    firma = _FIRMAS_GEOMETRIA.get(nivel) or _firma_geometria(nivel)
    return {
        "nivel": nivel,
        "filtro_nivel": filtro_nivel,
        "filtro_codigo": int(filtro_codigo) if filtro_codigo is not None else None,
        "version": firma,
    }


def obtener_geometria_serializada(nivel, filtro_nivel=None, filtro_codigo=None):
    """Devuelve GeoJSON sin valores censales y lo conserva serializado en RAM."""
    inicio = perf_counter()
    referencia = referencia_geometria(nivel, filtro_nivel, filtro_codigo)
    clave = (nivel, filtro_nivel, referencia["filtro_codigo"], referencia["version"])
    with _GEOMETRY_LOCK:
        contenido = _GEOMETRIAS_JSON.get(clave)
    if contenido is not None:
        LOG.info("[tiempo] geometria_api[%s]=%.3fs cache=True bytes=%s",
                 nivel, perf_counter() - inicio, len(contenido))
        return contenido, referencia["version"]

    gdf = _cargar_geometria(nivel)
    intencion = {
        "filtro_geografico_nivel": filtro_nivel,
        "filtro_geografico_codigo": filtro_codigo,
    }
    gdf = _filtrar_geometrias(gdf, nivel, intencion)
    if gdf.empty:
        raise ValueError("No hay geometrías para el filtro solicitado.")
    info = NIVELES[nivel]
    centros = gdf.geometry.representative_point()
    salida = gdf[["geometry", info["campo_nombre"], info["campo_gdb"]]].copy()
    salida["centro_lon"] = centros.x
    salida["centro_lat"] = centros.y
    salida = salida.rename(columns={
        info["campo_nombre"]: "nombre", info["campo_gdb"]: "codigo",
    })
    # to_json normaliza los escalares numpy y omite el índice interno.
    contenido = salida.to_json(drop_id=True, ensure_ascii=False).encode("utf-8")
    with _GEOMETRY_LOCK:
        _GEOMETRIAS_JSON[clave] = contenido
    LOG.info("[tiempo] geometria_api[%s]=%.3fs cache=False poligonos=%s bytes=%s",
             nivel, perf_counter() - inicio, len(salida), len(contenido))
    return contenido, referencia["version"]


def precalentar_geometrias(niveles=None):
    """Carga y serializa las capas configuradas al iniciar el servidor."""
    niveles = list(niveles or NIVELES)
    inicio = perf_counter()
    with _PREWARM_LOCK:
        _ESTADO_PRECALENTAMIENTO.update(
            estado="en_curso", niveles_listos=[], errores={}, inicio_segundos=0.0
        )
    for nivel in niveles:
        if nivel not in NIVELES:
            with _PREWARM_LOCK:
                _ESTADO_PRECALENTAMIENTO["errores"][nivel] = "Nivel desconocido"
            continue
        paso = perf_counter()
        try:
            obtener_geometria_serializada(nivel)
            with _PREWARM_LOCK:
                _ESTADO_PRECALENTAMIENTO["niveles_listos"].append(nivel)
            LOG.info("[precalentamiento] nivel=%s listo tiempo=%.3fs",
                     nivel, perf_counter() - paso)
        except Exception as exc:
            with _PREWARM_LOCK:
                _ESTADO_PRECALENTAMIENTO["errores"][nivel] = str(exc)
            LOG.exception("[precalentamiento] nivel=%s error=%s", nivel, exc)
    with _PREWARM_LOCK:
        errores = bool(_ESTADO_PRECALENTAMIENTO["errores"])
        listos = bool(_ESTADO_PRECALENTAMIENTO["niveles_listos"])
        _ESTADO_PRECALENTAMIENTO["estado"] = (
            "parcial" if errores and listos else "error" if errores else "listo"
        )
        _ESTADO_PRECALENTAMIENTO["duracion_segundos"] = round(
            perf_counter() - inicio, 3
        )
    LOG.info("[precalentamiento] estado=%s tiempo_total=%.3fs",
             _ESTADO_PRECALENTAMIENTO["estado"], perf_counter() - inicio)


def estado_precalentamiento():
    """Copia segura para el endpoint de salud."""
    with _PREWARM_LOCK:
        return deepcopy(_ESTADO_PRECALENTAMIENTO)


@lru_cache(maxsize=64)
def _consultar_sql(sql, ruta, mtime_ns, size):
    """Cachea agregados pequeños; invalida al cambiar tamaño o fecha del parquet."""
    with duckdb.connect(database=":memory:") as conexion:
        return conexion.execute(sql).df()


def _filtrar_geometrias(gdf, nivel, intencion):
    """Selecciona polígonos del territorio solicitado, incluso sin observaciones."""
    filtro = intencion.get("filtro_geografico_nivel")
    codigo = intencion.get("filtro_geografico_codigo")
    if not filtro or codigo is None:
        return gdf
    codigo = int(codigo)
    campo = NIVELES[filtro]["campo_gdb"]
    if campo in gdf.columns:
        return gdf.loc[pd.to_numeric(gdf[campo], errors="coerce") == codigo].copy()
    # Para capas sin código de la unidad superior, selecciona por un punto
    # interior. No usa intersección de bordes (incluiría territorios vecinos).
    orden = {"region": 0, "provincia": 1, "comuna": 2}
    if orden[filtro] > orden[nivel]:
        raise ValueError("El filtro es más específico que el nivel del mapa; pedir ese nivel o uno inferior.")
    limite = _cargar_geometria(filtro)
    limite = limite.loc[limite[campo] == codigo]
    if limite.empty:
        raise ValueError("El territorio solicitado no existe en la cartografía.")
    mascara = gdf.geometry.representative_point().apply(
        lambda punto: any(poligono.covers(punto) for poligono in limite.geometry))
    return gdf.loc[mascara].copy()


def _ejecutar_distribucion(intencion, progreso, inicio):
    """Calcula una distribución categórica para cada polígono del mapa."""
    avisar = progreso or (lambda etapa, terminado: None)
    tabla = intencion["tabla"]
    nombre_variable = intencion["variable"]
    if tabla not in TABLAS_PARQUET or nombre_variable not in VARIABLES[tabla]["variables"]:
        raise ValueError("Tabla o variable desconocida para la distribución.")
    ruta = _ruta_parquet(tabla)
    variable = '"' + nombre_variable.replace('"', '""') + '"'
    nivel = intencion.get("nivel_geografico", "comuna")
    if nivel not in NIVELES:
        raise ValueError("Nivel geográfico no válido.")
    nivel_info = NIVELES[nivel]
    col_geo = nivel_info["col_parquet"]
    filtros = []
    f_nivel = intencion.get("filtro_geografico_nivel")
    f_codigo = intencion.get("filtro_geografico_codigo")
    if bool(f_nivel) != (f_codigo is not None) or (f_nivel and f_nivel not in NIVELES):
        raise ValueError("Filtro territorial incompleto o no válido.")
    if f_nivel:
        filtros.append(f"{NIVELES[f_nivel]['col_parquet']} = {int(f_codigo)}")
    for filtro_numerico in intencion.get("filtros_numericos") or []:
        filtros.extend(_condiciones_rango(tabla, filtro_numerico, incluir_solicitado=True))
    if intencion.get("edad_minima") is not None:
        edad = intencion.get("variable_edad")
        if tabla != "personas" or edad not in VARIABLES[tabla]["variables"]:
            raise ValueError("Variable de edad no válida.")
        edad_sql = '"' + edad.replace('"', '""') + '"'
        filtros.append(f"TRY_CAST({edad_sql} AS DOUBLE) >= {int(intencion['edad_minima'])}")
    validas = intencion.get("categorias_validas") or categorias_validas(tabla, nombre_variable)
    if len(validas) < 2:
        raise ValueError("La variable no tiene suficientes categorías válidas.")
    lista_validas = ", ".join("'" + str(v).replace("'", "''") + "'" for v in validas)
    filtros.append(f"CAST({variable} AS VARCHAR) IN ({lista_validas})")
    where = "WHERE " + " AND ".join(filtros)
    ruta_sql = ruta.as_posix().replace("'", "''")
    sql = f"""
        SELECT {col_geo} AS codigo,
               CAST({variable} AS VARCHAR) AS categoria,
               COUNT(*) AS valor
        FROM read_parquet('{ruta_sql}')
        {where}
        GROUP BY {col_geo}, categoria
        ORDER BY {col_geo}, valor DESC, categoria
    """
    stat = ruta.stat()
    paso = perf_counter()
    with _SQL_CACHE_LOCK:
        antes = _consultar_sql.cache_info().hits
        df = _consultar_sql(sql, str(ruta), stat.st_mtime_ns, stat.st_size).copy()
        hit = _consultar_sql.cache_info().hits > antes
    LOG.info("[tiempo] distribucion_duckdb=%.3fs cache=%s filas=%s",
             perf_counter() - paso, hit, len(df))
    avisar(2, True)
    avisar(3, False)
    geometria = referencia_geometria(
        nivel, intencion.get("filtro_geografico_nivel"),
        intencion.get("filtro_geografico_codigo"),
    )
    avisar(3, True)
    avisar(4, False)
    df["codigo"] = df["codigo"].astype("Int64")
    df["categoria"] = df["categoria"].astype(str)
    etiquetas = VARIABLES[tabla]["variables"][nombre_variable]["categorias"]
    # Se usan las mismas cuatro categorías principales en todos los polígonos,
    # calculadas sobre el territorio completo de la consulta.
    totales_categoria = (df.groupby("categoria", as_index=False)["valor"].sum()
                         .sort_values(["valor", "categoria"], ascending=[False, True]))
    codigos_ordenados = totales_categoria["categoria"].tolist()
    principales = codigos_ordenados[:4] if len(codigos_ordenados) > 4 else codigos_ordenados
    agrupar_otros = len(codigos_ordenados) > 4
    categorias_grafico = [
        {"codigo": codigo, "etiqueta": str(etiquetas.get(codigo, codigo))}
        for codigo in principales
    ]
    if agrupar_otros:
        categorias_grafico.append({"codigo": "otros", "etiqueta": "Otros"})

    nombres = VARIABLES.get("geografia", {}).get(nivel, {})
    datos = []
    for codigo, grupo in df.groupby("codigo"):
        conteos = {str(fila.categoria): int(fila.valor)
                   for fila in grupo.itertuples(index=False)}
        total = sum(conteos.values())
        distribucion = []
        for categoria in principales:
            valor = conteos.get(categoria, 0)
            distribucion.append({
                "codigo": categoria,
                "etiqueta": str(etiquetas.get(categoria, categoria)),
                "valor": valor,
                "porcentaje": 100.0 * valor / total if total else None,
            })
        if agrupar_otros:
            valor_otros = sum(valor for categoria, valor in conteos.items()
                              if categoria not in principales)
            distribucion.append({
                "codigo": "otros", "etiqueta": "Otros", "valor": valor_otros,
                "porcentaje": 100.0 * valor_otros / total if total else None,
            })
        codigo_json = _codigo_json(codigo)
        nombre = next((v for k, v in nombres.items()
                       if str(k).isdigit() and str(codigo_json).isdigit()
                       and int(k) == int(codigo_json)), str(codigo_json))
        datos.append({"codigo": codigo_json, "nombre": nombre,
                      "distribucion": distribucion, "total": total})
    resultado = {
        "tipo_visualizacion": "tortas_mapa",
        "datos": datos,
        "geometria": geometria,
        "nivel_geografico": nivel,
        "categorias_grafico": categorias_grafico,
        "_sql_ejecutada": sql,
    }
    avisar(4, True)
    LOG.info("[tiempo] distribucion_total=%.3fs filas_salida=%s",
             perf_counter() - inicio, len(datos))
    return resultado


def ejecutar_consulta(intencion: dict, progreso=None) -> dict:
    """Agrega datos y devuelve una referencia a la cartografía reutilizable."""
    inicio = perf_counter()
    # Cada notificación corresponde al inicio o término de trabajo real.
    avisar = progreso or (lambda etapa, terminado: None)
    avisar(2, False)
    if intencion.get("operacion") == "distribucion":
        return _ejecutar_distribucion(intencion, avisar, inicio)
    nivel = intencion.get("nivel_geografico", "comuna")
    if nivel not in NIVELES:
        raise ValueError("Nivel geográfico no válido.")
    nivel_info = NIVELES[nivel]
    ruta = _ruta_parquet(intencion["tabla"])
    sql = _construir_sql(intencion, nivel_info, ruta)
    stat = ruta.stat()
    paso = perf_counter()
    with _SQL_CACHE_LOCK:
        antes = _consultar_sql.cache_info().hits
        df = _consultar_sql(sql, str(ruta), stat.st_mtime_ns, stat.st_size).copy()
        hit = _consultar_sql.cache_info().hits > antes
    df["codigo"] = df["codigo"].astype("Int64")
    LOG.info("[tiempo] consulta_duckdb=%.3fs cache=%s filas=%s", perf_counter() - paso, hit, len(df))
    avisar(2, True)
    avisar(3, False)
    geometria = referencia_geometria(
        nivel, intencion.get("filtro_geografico_nivel"),
        intencion.get("filtro_geografico_codigo"),
    )
    avisar(3, True)
    avisar(4, False)
    paso = perf_counter()
    nombres = VARIABLES.get("geografia", {}).get(nivel, {})
    datos = []
    for fila in df.itertuples(index=False):
        codigo = _codigo_json(fila.codigo)
        nombre = next((v for k, v in nombres.items()
                       if str(k).isdigit() and str(codigo).isdigit()
                       and int(k) == int(codigo)), str(codigo))
        datos.append({"codigo": codigo, "nombre": nombre,
                      "valor": _valor_json(fila.valor)})
    validos = df["valor"].dropna()
    LOG.info("[tiempo] organizar_resultados=%.3fs motor_total=%.3fs filas_salida=%s",
             perf_counter() - paso, perf_counter() - inicio, len(datos))
    avisar(4, True)
    return {"datos": datos, "geometria": geometria,
            "nivel_geografico": nivel,
            "_sql_ejecutada": sql,
            "valores": {"min": float(validos.min()) if len(validos) else None,
                        "max": float(validos.max()) if len(validos) else None}}
