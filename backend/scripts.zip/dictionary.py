# -*- coding: utf-8 -*-
"""
Carga los diccionarios de variables del Censo 2024 y de la cartografía,
y ofrece una búsqueda liviana de "candidatos" (variables y unidades
geográficas) relevantes para una consulta en lenguaje natural.

La idea es NO mandarle al LLM local todo el diccionario (sería demasiado
texto para un modelo liviano). En vez de eso, primero acotamos con un
buscador simple basado en texto, y solo esos candidatos (pocos) se le
pasan al LLM para que decida.
"""
import json
import re
from pathlib import Path
from unidecode import unidecode

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

with open(DATA_DIR / "diccionario_variables.json", encoding="utf-8") as f:
    VARIABLES = json.load(f)

with open(DATA_DIR / "diccionario_geografico.json", encoding="utf-8") as f:
    GEOGRAFIA_CAMPOS = json.load(f)

# Tablas disponibles y su archivo parquet correspondiente
TABLAS_PARQUET = {
    "personas": "personas_censo2024.parquet",
    "hogares": "hogares_censo2024.parquet",
    "viviendas": "viviendas_censo2024.parquet",
}

# Palabras vacías simples en español para no ensuciar la búsqueda
STOPWORDS = {
    "el", "la", "los", "las", "de", "del", "en", "por", "un", "una", "con",
    "que", "y", "a", "para", "cuantas", "cuantos", "cuántas", "cuántos",
    "cual", "cuál", "es", "son", "hay", "muestrame", "muéstrame", "mapa",
    "quiero", "ver", "dame", "porcentaje", "cantidad", "numero", "número",
    "total", "segun", "según", "cada", "sobre", "tiene", "tienen",
}

# Equivalencias de uso cotidiano. Se expanden, no se reemplazan, para
# conservar la diferencia estadística entre la entidad vivienda y la
# categoría Casa de la variable «Tipo de vivienda particular».
SINONIMOS_BUSQUEDA = {
    "casa": {"casa", "vivienda"},
    "casas": {"casa", "vivienda"},
    "vivienda": {"vivienda"},
    "viviendas": {"vivienda"},
    "domicilio": {"vivienda"},
    "domicilios": {"vivienda"},
}


def _norm(txt: str) -> str:
    return unidecode(str(txt)).lower()


def _tokens(txt: str):
    """Tokeniza y agrega equivalencias controladas del dominio censal."""
    resultado = []
    for token in re.findall(r"[a-z0-9]+", _norm(txt)):
        if not token or token in STOPWORDS:
            continue
        resultado.extend(sorted(SINONIMOS_BUSQUEDA.get(token, {token})))
    return resultado


def es_ambito_nacional(consulta: str) -> bool:
    """Reconoce Chile como ámbito, sin confundirlo con lugar de nacimiento."""
    q = _norm(consulta)
    nacimiento = re.search(
        r"\b(?:nac(?:io|ieron|ida|ido|idas|idos)|nacimiento|fuera de chile)\b",
        q,
    )
    if nacimiento:
        return False
    return bool(re.search(
        r"\b(?:en|de|para)\s+(?:todo\s+)?chile\b|"
        r"\b(?:todo\s+)?(?:el\s+)?pais\b|"
        r"\b(?:a\s+)?nivel\s+nacional\b|"
        r"\bambito\s+nacional\b",
        q,
    ))


# ---------------------------------------------------------------------------
# Índice de variables: para cada (tabla, variable) guardamos un texto de
# búsqueda que junta descripción + etiquetas de categorías.
# ---------------------------------------------------------------------------
_VAR_INDEX = []
for tabla, contenido in VARIABLES.items():
    if tabla == "geografia":
        continue
    for nombre_var in contenido["orden"]:
        info = contenido["variables"][nombre_var]
        texto = info["descripcion"] + " " + " ".join(info["categorias"].values())
        _VAR_INDEX.append({
            "tabla": tabla,
            "variable": nombre_var,
            "descripcion": info["descripcion"],
            "categorias": info["categorias"],
            "texto_norm": _norm(texto),
            "tokens": set(_tokens(texto)),
        })


def buscar_variables(consulta: str, top_n: int = 6):
    """Devuelve las top_n variables más relacionadas con la consulta."""
    q_tokens = set(_tokens(consulta))
    # En «casas en Chile», Chile define el ámbito y no una categoría. Así se
    # evita favorecer variables como lugar de nacimiento o nacionalidad.
    if es_ambito_nacional(consulta):
        q_tokens.difference_update({"chile", "pais", "nacional", "ambito"})
    q_norm = _norm(consulta)
    puntajes = []
    for item in _VAR_INDEX:
        score = 0
        # coincidencia de tokens completos
        score += 3 * len(q_tokens & item["tokens"])
        # coincidencia de subcadena directa (ej. "internet", "hacinamiento")
        for tok in q_tokens:
            if len(tok) >= 4 and tok in item["texto_norm"]:
                score += 1
        if score > 0:
            puntajes.append((score, item))
    puntajes.sort(key=lambda x: x[0], reverse=True)
    return [p[1] for p in puntajes[:top_n]]


# ---------------------------------------------------------------------------
# Índice geográfico: nombres de región/provincia/comuna normalizados
# ---------------------------------------------------------------------------
_GEO_INDEX = []
for nivel in ("region", "provincia", "comuna"):
    for codigo, nombre in VARIABLES["geografia"][nivel].items():
        _GEO_INDEX.append({
            "nivel": nivel,
            "codigo": codigo,
            "nombre": nombre,
            "nombre_norm": _norm(nombre),
        })

# Alias territoriales controlados. La clave usa el nombre oficial normalizado
# y el nivel; el código territorial siempre se recupera desde el diccionario.
ALIAS_TERRITORIALES = {
    ("comuna", "isla de pascua"): {"rapa nui", "rapanui"},
}


def nombres_geograficos(item):
    """Alias de nombres conocidos; el código siempre proviene del diccionario."""
    nombre = item["nombre_norm"]
    corto = re.sub(r"^(?:region|provincia|comuna)\s+(?:de\s+)?", "", nombre)
    # Conserva variantes con y sin artículo («La Araucanía»/«Araucanía»).
    sin_articulo = re.sub(r"^(?:la|el|los|las)\s+", "", corto)
    nombres = {nombre, corto, sin_articulo}
    if item["nivel"] == "region" and re.search(r"\bmetropolitana\b", nombre):
        nombres.update({"metropolitana", "metropolitana de santiago"})
    # Incorpora denominaciones alternativas solo cuando existe en el
    # diccionario la unidad territorial oficial correspondiente.
    for (nivel, oficial), alias in ALIAS_TERRITORIALES.items():
        if item["nivel"] == nivel and oficial in {nombre, corto, sin_articulo}:
            nombres.update(alias)
    return sorted(nombres, key=len, reverse=True)


def buscar_geografia(consulta: str, top_n: int = 5):
    """Busca nombres completos o alias comprobados con límites de palabra."""
    q = _norm(consulta)
    encontrados = []
    for item in _GEO_INDEX:
        coincidencias = [nombre for nombre in nombres_geograficos(item)
                        if len(nombre) >= 4 and re.search(r"\b" + re.escape(nombre) + r"\b", q)]
        if coincidencias:
            encontrados.append((max(map(len, coincidencias)), item))
    encontrados.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in encontrados[:top_n]]


def detectar_nivel_geografico(consulta: str) -> str:
    """Prioriza niveles explícitos; en empate, comuna > provincia > región."""
    q = _norm(consulta)
    niveles = (("comuna", r"comunas?|comunal"),
               ("provincia", r"provincias?|provincial"),
               ("region", r"region(?:es)?|regional"))
    # Un nombre territorial después de «en/para la región» es un filtro.
    for nivel, patron in niveles:
        if re.search(r"\b(?:por|cada|a nivel de|a nivel|desglosad[oa]s? por)\s+"
                     r"(?:(?:la|las|el|los)\s+)?(?:" + patron + r")\b", q):
            return nivel
    # Una consulta nacional necesita un desglose territorial para producir un
    # mapa. Si el usuario no indicó otro nivel, se muestran las regiones.
    if es_ambito_nacional(consulta):
        return "region"
    # Descarta menciones singulares que introducen un lugar concreto.
    q = re.sub(r"\b(?:en|para|de)\s+(?:(?:la|el)\s+)?"
               r"(?:region|provincia|comuna)\b(?:\s+de(?:l)?)?", " ", q)
    for nivel, patron in niveles:
        if re.search(r"\b(?:" + patron + r")\b", q):
            return nivel
    # Cuando no se indica nivel territorial, el mapa nacional se presenta por
    # región. Los niveles explícitos revisados arriba mantienen prioridad.
    return "region"


def filtro_geografico_explicito(consulta: str):
    """Distingue lugares homónimos según «región/provincia/comuna de X»."""
    q = _norm(consulta)
    encontrados = []
    for item in _GEO_INDEX:
        for nombre in nombres_geograficos(item):
            # Retira el prefijo cuando el nombre oficial ya lo contiene.
            nombre = re.sub(r"^(?:region|provincia|comuna)\s+(?:de\s+)?", "", nombre)
            patron = (r"\b" + item["nivel"] + r"\s+(?:de\s+|del\s+)?(?:(?:la|el|los|las)\s+)?"
                      + re.escape(nombre) + r"\b")
            if re.search(patron, q):
                encontrados.append(item)
                break
    encontrados.sort(key=lambda x: len(x["nombre_norm"]), reverse=True)
    return encontrados[0] if encontrados else None


def detectar_operacion(consulta: str) -> str:
    q = _norm(consulta)
    # Los índices y razones necesitan una fórmula registrada; no deben
    # degradarse silenciosamente a un conteo.
    if re.search(r"\b(?:indice|razon)\b", q):
        return "razon"
    if "porcentaje" in q or "%" in q or "proporcion" in q or "tasa" in q:
        return "porcentaje"
    if "promedio" in q or "media" in q:
        return "promedio"
    return "conteo"


def es_categoria_invalida(codigo, etiqueta) -> bool:
    """Reconoce códigos que no pertenecen al universo de un porcentaje."""
    codigo_norm = _norm(codigo).strip()
    etiqueta_norm = _norm(etiqueta).strip()
    if codigo_norm in {"", "na", "nan", "null", "none"} or codigo_norm.startswith("-"):
        return True
    patrones = (
        "no aplica", "no respuesta", "sin respuesta", "no responde",
        "valor suprimido", "valor ignorado", "anonimizado", "missing",
        "sin informacion", "dato no disponible",
    )
    return any(patron in etiqueta_norm for patron in patrones)


def categorias_validas(tabla: str, variable: str):
    """Devuelve códigos válidos usando exclusivamente el diccionario cargado."""
    info = VARIABLES.get(tabla, {}).get("variables", {}).get(variable, {})
    return [str(codigo) for codigo, etiqueta in info.get("categorias", {}).items()
            if not es_categoria_invalida(codigo, etiqueta)]
